/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LCD.h"
#include "DS1307.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int i, j;
const char *DAYS_OF_WEEK[7] = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };
uint8_t date;
uint8_t month;
uint16_t year;
uint8_t dow;
uint8_t hour;
uint8_t minute;
uint8_t second;

/* USER CODE END 0 */

void Doc_thoi_gian (void)
{
	date = DS1307_GetDate();
	month = DS1307_GetMonth();
	year = DS1307_GetYear();
	dow = DS1307_GetDayOfWeek();
	hour = DS1307_GetHour();
	minute = DS1307_GetMinute();
	second = DS1307_GetSecond();
}

void Hien_thi_thoi_gian (void)
{
	LCD_xy(0, 0);
	LCD_ghi_chuoi("TIME: ");
	LCD_ghi_so_thuc(hour, 0);
	LCD_ghi_chuoi(":");
	LCD_ghi_so_thuc(minute, 0);
	LCD_ghi_chuoi(":");
	LCD_ghi_so_thuc(second, 0);
	LCD_xy(1, 0);
	LCD_ghi_chuoi((char*)DAYS_OF_WEEK[dow]);
	LCD_ghi_chuoi(" ");
	LCD_ghi_so_thuc(date, 0);
	LCD_ghi_chuoi("/");
	LCD_ghi_so_thuc(month, 0);
	LCD_ghi_chuoi("/");
	LCD_ghi_so_thuc(year, 0);
}

/**
  * @brief This function handles TIM3 global interrupt.
  */
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */
	switch (i)
	{
		case 0:
			Doc_thoi_gian();
			Hien_thi_thoi_gian();
			break;
		case 1:
			if (j == 0)
			{
				LCD_xy(0, 6);
				LCD_ghi_so_thuc(hour, 0);
			}
			else
			{
				LCD_xy(0, 6);
				LCD_ghi_chuoi("__");
			}
			break;
		case 2:
			if (j == 0)
			{
				LCD_xy(0, 9);
				LCD_ghi_so_thuc(minute, 0);
			}
			else
			{
				LCD_xy(0, 9);
				LCD_ghi_chuoi("__");
			}
			break;
		case 3:
			if (j == 0)
			{
				LCD_xy(1, 0);
				LCD_ghi_chuoi((char*)DAYS_OF_WEEK[dow]);
			}
			else
			{
				LCD_xy(1, 0);
				LCD_ghi_chuoi("___");
			}
			break;
		case 4:
			if (j == 0)
			{
				LCD_xy(1, 4);
				LCD_ghi_so_thuc(date, 0);
			}
			else
			{
				LCD_xy(1, 4);
				LCD_ghi_chuoi("__");
			}
			break;
		case 5:
			if (j == 0)
			{
				LCD_xy(1, 7);
				LCD_ghi_so_thuc(month, 0);
			}
			else
			{
				LCD_xy(1, 7);
				LCD_ghi_chuoi("__");
			}
			break;
		case 6:
			if (j == 0)
			{
				LCD_xy(1, 10);
				LCD_ghi_so_thuc(year, 0);
			}
			else
			{
				LCD_xy(1, 10);
				LCD_ghi_chuoi("____");
			}
			break;
	}
	j = 1 - j;
	
  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */

  /* USER CODE END TIM3_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[9:5] interrupts.
  */
void EXTI9_5_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI9_5_IRQn 0 */
	if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9) == 0)
	{
		while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9) == 0);
		switch (i)
		{
			case 1:
				hour = (hour + 1) % 24;
				DS1307_SetHour(hour);
				break;
			case 2:
				minute = (minute + 1) % 60;
				DS1307_SetMinute(minute);
				break;
			case 3:
				dow = (dow + 1) % 7;
				DS1307_SetDayOfWeek(dow);
				break;
			case 4:
				date = date + 1;
				if (date>31)
				date = 1;
				DS1307_SetDate(date);
				break;
			case 5:
				month = month + 1;
			if (month>12)
				month = 1;
				DS1307_SetMonth(month);
				break;
			case 6:
				year = (year + 1);
				DS1307_SetYear(year);
				break;
		}
	}

	if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) == 0)
	{
		while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) == 0);
		i = (i + 1) % 7;
		Hien_thi_thoi_gian();
	}

  /* USER CODE END EXTI9_5_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8);
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_9);
  /* USER CODE BEGIN EXTI9_5_IRQn 1 */

  /* USER CODE END EXTI9_5_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[15:10] interrupts.
  */
void EXTI15_10_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI15_10_IRQn 0 */
	switch (i)
			{
				case 1:
					hour = hour - 1;
					if (hour == 255)
						hour = 23;
					DS1307_SetHour(hour);
					break;
				case 2:
					minute = minute - 1;
					if (minute == 255)
						minute = 59;
					DS1307_SetMinute(minute);
					break;
				case 3:
					dow = dow - 1;
					if (dow == 255)
						dow = 6;
					DS1307_SetDayOfWeek(dow);
					break;
				case 4:
					date = date - 1;
					if (date<1)
						date = 31;
					DS1307_SetDate(date);
					break;
				case 5:
					month = month - 1;
					if (month<1)
						month = 12;
					DS1307_SetMonth(month);
					break;
				case 6:
					year = (year - 1);
					DS1307_SetYear(year);
					break;
			}

  /* USER CODE END EXTI15_10_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_10);
  /* USER CODE BEGIN EXTI15_10_IRQn 1 */

  /* USER CODE END EXTI15_10_IRQn 1 */
}

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
	LCD_Init();
	DS1307_Init(&hi2c1);
	LCD_xy(0, 0);
	LCD_ghi_chuoi("    NHOM  04    ");
	LCD_xy(1, 0);
	LCD_ghi_chuoi("REAL-TIME CLOCK");
	HAL_Delay(2000);
	LCD_xoa_man_hinh();
	HAL_TIM_Base_Start_IT(&htim3);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 1000 - 1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 8000 - 1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pins : PA8 PA9 PA10 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
